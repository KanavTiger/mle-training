# example_package_Kanav/__init__.py
__version__ = '0.0.1'
